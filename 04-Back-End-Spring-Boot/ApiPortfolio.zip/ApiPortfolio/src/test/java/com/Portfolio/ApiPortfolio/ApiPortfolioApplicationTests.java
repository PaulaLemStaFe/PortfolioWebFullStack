package com.Portfolio.ApiPortfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
